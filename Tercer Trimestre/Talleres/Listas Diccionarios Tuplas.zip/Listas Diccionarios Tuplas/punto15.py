# Crea una lista llamada valores con todos los valores del diccionario persona.

persona = {"nombre":"vicky", "edad":19, "ciudad":"San Antonio de los Altos"}
valores = list(persona.values())# con values acumula las valores de cada clave/campo del diccionario
print(valores)