#  crea una lista llamada mixta con una cadena de texto, un número entero y un número decimal

mixta = ["Vicky","Vielma", 19, 1.74]
print(mixta) 