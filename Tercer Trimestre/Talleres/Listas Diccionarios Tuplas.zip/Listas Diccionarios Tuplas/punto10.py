#  Crea un diccionario llamado persona con las claves "nombre", "edad" y "ciudad", y los valores correspondientes
persona = {"nombre":"vicky", "edad":19, "ciudad":"San Antonio de los Altos"}
print(persona)