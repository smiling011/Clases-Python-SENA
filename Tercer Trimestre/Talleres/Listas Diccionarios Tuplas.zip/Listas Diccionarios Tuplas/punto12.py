# Modifica el valor de la clave "edad" del diccionario persona.

persona = {"nombre":"vicky", "edad":int(input("Escribe tu edad: ")), "ciudad":"San Antonio de los Altos"}
print(persona16)