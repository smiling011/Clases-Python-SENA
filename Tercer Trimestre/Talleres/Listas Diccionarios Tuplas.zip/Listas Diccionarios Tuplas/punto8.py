#  Crea una tupla llamada meses con los nombres de los meses del año
meses = ("enero","febrero","marzo","abril","mayo","junio","julio",
         "agosto","septiembre","octubre","noviembre","diciempre")
print(meses)