#  Accede al segundo elemento de la tupla meses.

meses = ("enero","febrero","marzo","abril","mayo","junio","julio",
         "agosto","septiembre","octubre","noviembre","diciempre")
var = meses[1]
print(var)
