#  Crea una lista llamada claves con todas las claves del diccionario persona.

persona = {"nombre":"vicky", "edad":19, "ciudad":"San Antonio de los Altos"}
claves = list(persona.keys())# con keys acumula las claves del diccionario, osea los campos
print(claves)
