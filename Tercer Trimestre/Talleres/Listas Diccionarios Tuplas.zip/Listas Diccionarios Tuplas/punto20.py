# Crea una lista llamada ordenada con los elementos de la lista
# números ordenados de menor a mayor utilizando el método sort().
ordenada = [1,9,8,6,7,5,3,4,2,0]
ordenada.sort()# (sort) organiza de menor a mayor 
print(ordenada)