# Crea una lista llamada cuadrados con los cuadrados de los números 
# del 1 al 5 utilizando una lista por comprensión.

cuadrados = [x**2 for x in range(1, 6)] #raiz cudrada del rango del 1 al 5
print(cuadrados)