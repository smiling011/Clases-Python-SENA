# Crea una lista llamada sublista que contenga los elementos del índice 2 al 4 de la lista números

sublista = [1,2,3,4,5,6,7,8,9,10]
print(sublista[2:5])