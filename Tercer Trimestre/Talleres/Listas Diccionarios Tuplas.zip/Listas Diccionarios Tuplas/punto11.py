# Accede al valor de la clave "edad" del diccionario persona.

persona = {"nombre":"vicky", "edad":19, "ciudad":"San Antonio de los Altos"}
print(persona["edad"])