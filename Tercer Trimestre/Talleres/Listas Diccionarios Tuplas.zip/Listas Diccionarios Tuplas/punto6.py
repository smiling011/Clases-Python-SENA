#  Agrega el número 11 al final de la lista números.
num = [1,2,3,4,5,6,7,8,9,10]
num.append(11)
print(num) 